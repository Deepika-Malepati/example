﻿using System;

namespace GitHub.DistributedTask.Pipelines
{
    public static class RepositoryTypes
    {
        public static readonly String GitHub = nameof(GitHub);
    }
}
