using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Runner.Worker")]
[assembly: InternalsVisibleTo("Test")]