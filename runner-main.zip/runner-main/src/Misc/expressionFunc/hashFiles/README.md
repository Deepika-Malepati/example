To compile this package (output will be stored in `Misc/layoutbin`) run `npm install && npm run all`.

> Note: this package also needs to be recompiled for dependabot PRs updating one of
> its dependencies.
