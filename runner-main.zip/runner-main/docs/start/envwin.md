# ![win](../res/win_med.png) Windows System Prerequisites

## Supported Versions

 - Windows 7 64-bit
 - Windows 8.1 64-bit
 - Windows 10 64-bit
 - Windows Server 2012 R2 64-bit
 - Windows Server 2016 64-bit
 - Windows Server 2019 64-bit

## [More .NET Core Prerequisites Information](https://docs.microsoft.com/en-us/dotnet/core/windows-prerequisites?tabs=netcore30)
